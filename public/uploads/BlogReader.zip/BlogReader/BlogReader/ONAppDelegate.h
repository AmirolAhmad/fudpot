//
//  ONAppDelegate.h
//  BlogReader
//
//  Created by Amirol Ahmad on 1/18/14.
//  Copyright (c) 2014 Osem Network. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ONAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
