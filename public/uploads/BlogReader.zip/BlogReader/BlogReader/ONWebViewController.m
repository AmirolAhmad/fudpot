//
//  ONWebViewController.m
//  BlogReader
//
//  Created by Amirol Ahmad on 1/19/14.
//  Copyright (c) 2014 Osem Network. All rights reserved.
//

#import "ONWebViewController.h"

@interface ONWebViewController ()

@end

@implementation ONWebViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:self.blogPostURL];
    [self.webView loadRequest:urlRequest];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
