//
//  ONWebViewController.h
//  BlogReader
//
//  Created by Amirol Ahmad on 1/19/14.
//  Copyright (c) 2014 Osem Network. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ONWebViewController : UIViewController

@property (strong,nonatomic) NSURL *blogPostURL;
@property (strong, nonatomic) IBOutlet UIWebView *webView;

@end
