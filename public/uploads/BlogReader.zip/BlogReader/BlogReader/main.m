//
//  main.m
//  BlogReader
//
//  Created by Amirol Ahmad on 1/18/14.
//  Copyright (c) 2014 Osem Network. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ONAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ONAppDelegate class]));
    }
}
