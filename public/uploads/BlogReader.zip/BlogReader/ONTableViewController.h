//
//  ONTableViewController.h
//  BlogReader
//
//  Created by Amirol Ahmad on 1/19/14.
//  Copyright (c) 2014 Osem Network. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ONTableViewController : UITableViewController

@property (strong, nonatomic) NSMutableArray *blogPosts;

@end
