//
//  ONTableViewController.m
//  BlogReader
//
//  Created by Amirol Ahmad on 1/19/14.
//  Copyright (c) 2014 Osem Network. All rights reserved.
//

#import "ONTableViewController.h"
#import "ONBlogPost.h"
#import "ONWebViewController.h"

@interface ONTableViewController ()

@end

@implementation ONTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSURL *blogURL = [NSURL URLWithString:@"http://www.acg-tube.com/api/get_recent_posts/"];
    
    NSData *jsonData = [NSData dataWithContentsOfURL:blogURL];
    
    NSError *error = nil;
    
    NSDictionary *dataDictionary = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
//    NSLog(@"%@", dataDictionary);
    
    self.blogPosts = [NSMutableArray array];
    
    NSArray *blogPostArray = [dataDictionary objectForKey:@"posts"];
    
    for (NSDictionary *bpDictionary in blogPostArray) {
        ONBlogPost *blogPost = [ONBlogPost blogPostWithTitle:[bpDictionary objectForKey:@"title"]];
        blogPost.author = [bpDictionary objectForKey:@"title_plain"];
        blogPost.thumbnail = [bpDictionary objectForKey:@"thumbnail"];
        blogPost.date = [bpDictionary objectForKey:@"date"];
        blogPost.url = [NSURL URLWithString:[bpDictionary objectForKey:@"url"]];
        [self.blogPosts addObject:blogPost];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [self.blogPosts count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    ONBlogPost *blogPost = [self.blogPosts objectAtIndex:indexPath.row];
    
    if ( [blogPost.thumbnail isKindOfClass:[NSString class]]) {
        NSData *imageData = [NSData dataWithContentsOfURL:blogPost.thumbnailURL];
        UIImage *image = [UIImage imageWithData:imageData];
        
        cell.imageView.image = image;
    } else {
        cell.imageView.image = [UIImage imageNamed:@"osemtech.png"];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@",blogPost.title];
    cell.textLabel.textColor = [UIColor colorWithRed: 176.0/255.0 green: 23.0/255.0 blue:31.0/255.0 alpha: 1];
    cell.textLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:11];
    cell.textLabel.numberOfLines = 0;
    
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ - %@",blogPost.author, [blogPost formattedDate]];
    cell.detailTextLabel.font = [UIFont fontWithName:@"Helvetica" size:10];
    
    return cell;
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    NSLog(@"preparing for segue: %@",segue.identifier);
    
    if ([segue.identifier isEqualToString:@"showBlogPost"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        ONBlogPost *blogPost = [self.blogPosts objectAtIndex:indexPath.row];
        ONWebViewController *wbc = (ONWebViewController *)segue.destinationViewController;
        wbc.blogPostURL = blogPost.url;
    }
}



@end
